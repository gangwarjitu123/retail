package com.utils;


import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
    static  SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
    public static Date getDate(String stringDate){
        try {
              Date date =simpleDateFormat.parse(stringDate);
            return date;
        }catch (Exception e){
            throw new RuntimeException("invalid date format");

        }
    }
    public static  Long getDaysDiff(Date date){
        long difference = new Date().getTime() - date.getTime();
        Long daysBetween = (difference / (1000*60*60*24));
        return daysBetween;

    }
}
