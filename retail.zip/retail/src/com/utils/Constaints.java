package com.utils;


import java.util.HashMap;


public class Constaints {
    public final static String dateformate="dd/MM/yyyy";
    public static HashMap<Integer,String> types= new HashMap<Integer, String>();
    static {
        types.put(1,"store");
        types.put(2,"affiliate");
    }
    public static HashMap<Integer,String> goodType= new HashMap<Integer, String>();
    static {
        goodType.put(1,"groceries");
        goodType.put(2,"others");
    }
}
