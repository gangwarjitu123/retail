package com;

import com.service.Billing;
import com.utils.Constaints;
import com.utils.Utility;

import java.util.Date;
import java.util.Scanner;

public class Main {
    static Scanner sc= new Scanner(System.in);
    public static void main(String[] args){
        System.out.println(" Enter  username");
        String username= sc.next();
        System.out.println(" Enter  user type id (ex .1 or 2) from below list" );
        Constaints.types.forEach((key,value)->{
            System.out.println(key +" : "+value);
        });
         Integer userTypeKey= sc.nextInt();
         System.out.println(" Enter  user created in below format " );
         System.out.println(Constaints.dateformate);
         String stringDate=sc.next();
         Date date= Utility.getDate(stringDate);
        System.out.println(" Enter Goods type  id ex .(1,or 2)from below list" );
        Constaints.goodType.forEach((key,value)->{
            System.out.println(key +" : "+value);
        });
        Integer goodType=sc.nextInt();


        System.out.println(" Enter Amount " );
        double amount=sc.nextDouble();




        Double billingAmount =Billing.doBilling(username,amount,date,userTypeKey,goodType);
        System.out.println("Final Amount after applying discount "+ billingAmount);

    }
}
