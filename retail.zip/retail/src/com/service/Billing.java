package com.service;

import com.utils.Constaints;
import com.utils.Utility;

import java.util.Date;

public class Billing {
        public  synchronized  static  Double doBilling(String username, Double amount , Date Usercreated,Integer type,Integer goodsType){
           Long days=  Utility.getDaysDiff(Usercreated);
           String userType= Constaints.types.get(type);
           double percentAmount=0d;
           Double finalAmount=0d;
           if(! (amount instanceof  Double)){
               throw  new RuntimeException("invalid amount");
           }
            String goodType= Constaints.goodType.get(goodsType);
          if(goodType!=null && !goodType.equalsIgnoreCase(Constaints.goodType.get(1))) {


        if (userType!=null && userType.equalsIgnoreCase("store")) {
               percentAmount=amount*0.30;
               amount=amount-percentAmount;

           } else if (userType!=null && userType.equalsIgnoreCase("affiliate")) {
               percentAmount=amount*0.10;
               amount=amount-percentAmount;

           }else if (days >= 720) {
            percentAmount=amount*0.05;
            amount=amount-percentAmount;


        }


          }
            Integer divAmount=(int) (amount/100);

            finalAmount=amount-(divAmount*5);
            return  finalAmount;

    }
}
