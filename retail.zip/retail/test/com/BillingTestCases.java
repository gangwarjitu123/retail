package com;


import com.service.Billing;
import org.junit.Test;

import java.util.Date;

import static junit.framework.Assert.assertEquals;

public class BillingTestCases{

    @Test
    public void TestBillingDeatils(){
        System.out.println("test cases running");
        Double finalAmount=Billing.doBilling("jitendra",240d,new Date("01/09/2018"),1,2);
        assertEquals(163.0,finalAmount);
    }


    @Test  // for groceries no discount
    public void anotherTestCasesForGroceries() {
        Double finalAmount = Billing.doBilling("harshit", 240d, new Date("01/09/2018"), 1, 1);
        assertEquals(230.0, finalAmount);
    }


    @Test  // for groceries no discount
    public void anotherTestCasesforOldUser() {
        Double finalAmount = Billing.doBilling("harshit", 200d, new Date("01/09/2093"), 3, 2);
        assertEquals(190.0, finalAmount);
    }
}
